<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$a1=$_POST['user'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$psw=md5($_POST['psw']);
			$addr=mysqli_real_escape_string($con, $_POST['addr']);
			$role=$_POST['role'];
			$bdate=$_POST['bdate'];
			mysqli_query($con, "INSERT INTO `user_master`(`um_name`, `um_cnct`, `um_mail`, `um_psw`, `um_add`, `um_role`, `um_bdate`) VALUES ('".$a1."','".$cnct."','".$mail."','".$psw."','".$addr."','".$role."','".$bdate."')")or die(mysqli_error($con));
			header("location:user.php");
		}
	}
	else
	{header("location:index.php");}
?>