<?php 
	
	include 'db.php';
	if(isset($_POST['submit_btn']))
	{
		$dis=$_POST['dis'];
		$sym=$_POST['sym'];
		
		$query=mysqli_query($con, "INSERT INTO `sdis_master`(`dis_id`,`sm_id`) VALUES ('".$dis."','".$sym."')") or mysqli_error();
		header("location:sym_dis.php");
	}
?>
