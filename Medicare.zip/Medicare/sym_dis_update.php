<?php
	include 'header.php';
	/*$id=$_REQUEST['id'];
	$category=mysqli_query($con, "select * from cat_master where cat_id=".$id);
	$cats=mysqli_fetch_array($category);*/
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Symptom-Disease Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
			<?php
			$id=$_REQUEST['id'];
			$query=mysqli_query($con,"SELECT * FROM sdis_master s, disease_master d, symptom_master s1 where                                     s.dis_id=d.dis_id and s.sm_id=s1.sm_id and s.s_dis_id=".$id);
			$rows = mysqli_fetch_array($query);
			?>
			    <form role="form" action="sym_dis_update1.php?id=<?php echo $id;?>" method="post" id="popup-validation">
					<div class="col-lg-12">
					<div class="form-group">
					<label>Disease</label>
			    <select class="validate[required] form-control" name="dis">
			<?php
				$disease=mysqli_query($con, "select * from disease_master");
				while($dis=mysqli_fetch_array($disease))
				{
			?>
			<option <?php if($rows['dis_id']==$dis['dis_id']){echo "selected";}?> value="<?php echo $dis['dis_id']; ?>"><?php             echo $dis['dis_name']; ?></option>
			<?php
			}
			?>
				</select>
					</div>
					<div class="form-group">
					<label>Sympton</label>
				<select class="validate[required] form-control" name="sym">
			<?php
				$sympton=mysqli_query($con, "select * from symptom_master");
				while($sym=mysqli_fetch_array($sympton))
				{
			?>
			<option <?php if($rows['sm_id']==$sym['sm_id']){echo "selected";}?> value="<?php echo $sym['sm_id']; ?>"><?php echo $sym['sm_name']; ?></option>
			<?php
			}
			?>
			</select>        
			</div>
			<div align="center">
			<button type="submit" name="submit_btn" class="btn btn-primary">Save Changes</button>
			<a href="sym_dis.php" class="btn btn-danger">Go Back</a>
			</div>
			</div>
			</div>
			</section>
			</div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>