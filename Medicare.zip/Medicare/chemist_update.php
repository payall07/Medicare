<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$chemist=mysqli_query($con, "select * from chemist_master where cm_id=".$id);
	$c1=mysqli_fetch_array($chemist);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Chemist Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <form class="form-horizontal" action="chemist_update1.php?id=<?php echo $id; ?>" method="post">
              <div class="box-body">
                 <div class="modal-body">
                <div class="form-group">
				<select class="form-control" name="user">
						<option selected disabled>Select User</option>
				<?php
						$chemist=mysqli_query($con, "select * from chemist_master where um_role ='Chemist'");
						while($st=mysqli_fetch_array($chemist))
						{
					?>
						<option <?php if($st['um_id']==$c1['um_id']) {echo "selected";}?> value="<?php echo $st['um_id']; ?>"><?php echo $st['um_name']; ?></option>
					<?php
						}
					?>
					
					  </select>
					  </div>
					  <div class="form-group">
					<input type="text" class="form-control" value="<?php echo $c1['cm_name']; ?>" name="cname" placeholder="Enter chemist name">
					 </div>
					 
					 <div class="form-group">
					<input type="text" class="form-control" value="<?php echo $c1['cm_cnct']; ?>" name="cnct" placeholder=				"Enter Chemist contact">
					</div>
					
					 <div class="form-group">
					<input type="text" class="form-control"  value="<?php echo $c1['cm_mail']; ?>"name="mail" placeholder="Enter Chemist mail">
					</div>
					
					 <div class="form-group"> 
					<input type="text" class="form-control" value="<?php echo $c1['cm_add']; ?>" name="add" placeholder="Enter Chemist Address">
					</div>
					
				 <div class="form-group">					<input type="text" class="form-control" value="<?php echo $c1['cm_lat']; ?>" name="lat" placeholder="Enter Chemist lat">
					</div>
					
					 <div class="form-group">
					<input type="text" class="form-control"  name="long" placeholder="Enter Chemist Long">
					</div>
					
					 <div class="form-group">
					<input type="text" class="form-control"  value="<?php echo $c1['cm_desc']; ?>"name="desc" placeholder="Enter Chemist Description">
					</div>
					
					 <div class="form-group">
					
					<input type="text" class="form-control"  value="<?php echo $c1['cm_regdate']; ?>"name="regdate" placeholder="Enter Chemist register date">
					 </div>
					<div class="col-sm-12">
					<input type="text" class="form-control"  value="<?php echo $c1['cm_logo']; ?>"name="logo" placeholder="logo">
                 
				  </div>
                </div>
              </div>
              <div class="box-footer">
                <a href="chemist.php" class="btn btn-default">Cancel</a>
                <button type="submit" name="add" class="btn btn-info pull-right">Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>