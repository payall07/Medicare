<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$state=$_POST['state'];
			mysqli_query($con, "UPDATE `state_master` SET `sm_name`='".$state."' WHERE `sm_id`=".$id);
			header("location:state.php");
		}
	}
	else
	{header("location:index.php");}
?>