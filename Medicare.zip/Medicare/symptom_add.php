<?php 
	
	include 'db.php';
	if(isset($_POST['submit_btn']))
	{
		$name=$_POST['sm_name'];
		
		$query=mysqli_query($con, "INSERT INTO `symptom_master`(`sm_name`) VALUES ('".$name."')") or mysqli_error();
		header("location:symptoms.php");
	}
?>