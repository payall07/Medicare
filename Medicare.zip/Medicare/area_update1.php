<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$area=$_POST['cname'];
			$city=$_POST['city'];
			$pin=$_POST['pin'];
			mysqli_query($con, "UPDATE `area_master` SET `ct_id`='".$city."', `am_name`='".$area."', `am_pin`='".$pin."' WHERE `am_id`=".$id);
			header("location:area.php");
		}
	}
	else
	{header("location:index.php");}
?>


			