<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		$id=$_REQUEST['id'];
		mysqli_query($con, "DELETE FROM `cat_master` WHERE `cat_id`=".$id);
		header("location:cat.php");
	}
	else
	{header("location:index.php");}
?>