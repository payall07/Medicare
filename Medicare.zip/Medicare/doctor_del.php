<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		$id=$_REQUEST['id'];
		mysqli_query($con, "DELETE FROM `doctor_master` WHERE `dm_id`=".$id);
		header("location:doctor.php");
	}
	else
	{header("location:index.php");}
?>