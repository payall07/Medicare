<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$user=$_POST['user'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$psw=md5($_POST['psw']);
			$add=$_POST['add'];
			$role=$_POST['role'];
			$bdate=$_POST['bdate'];
			mysqli_query($con, "UPDATE `user_master` SET `um_name`='".$user."',`um_cnct`='".$cnct."',`um_mail`='".$mail"',`um_psw`='".$psw."',`um_add`='".$add."',`um_role`='".$role."',`um_bdate`='".$bdate."' WHERE `um_id`=".$id);
			header("location:user.php");
		}
	}
	else
	{header("location:index.php");}
?>