<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$state=mysqli_query($con, "select * from state_master where sm_id=".$id);
	$a1=mysqli_fetch_array($state);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>State Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <form class="form-horizontal" action="state_update1.php?id=<?php echo $id; ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
                    <input type="text" class="form-control" value="<?php echo $a1['sm_name']; ?>" name="state" placeholder="Enter State Name">
                  </div>
                </div>
              </div>
              <div class="box-footer">
                <a href="state.php" class="btn btn-default">Cancel</a>
                <button type="submit" name="add" class="btn btn-info pull-right">Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
</body>
</html>
