<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$doc=mysqli_query($con, "select * from doctor_master where dm_id=".$id);
	$a1=mysqli_fetch_array($doc);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Doctor Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <form class="form-horizontal" action="doctor_update1.php?id=<?php echo $id; ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
				   <div class="modal-body">
                     <div class="form-group">
				        <select class="form-control" name="doctor">
						<option selected disabled>Select Doctor</option>
				<?php
						$doc=mysqli_query($con, "select * from user_master where um_role ='Doctor'");
						while($st=mysqli_fetch_array($doc))
						{
				?>
			       <option <?php if($st['um_id']==$a1['um_id']) {echo "selected";}?> value="<?php echo $st['um_id']; ?>"><?php echo $st['um_name']; ?></option>
					<?php
						}
					?>
					
					  </select>
					  </div>
					    <div class="form-group">
                    <input type="text" class="form-control" value="<?php echo $a1['dm_name']; ?>" name="doc" placeholder="Enter Doctor Name">
					 </div>
					  <div class="form-group">
					<input type="text" class="form-control" value="<?php echo $a1['dm_spec']; ?>"name="spec" placeholder="Specification ">
					 </div>
					  <div class="form-group">
				    <input type="text" class="form-control" value="<?php echo $a1['dm_exp']; ?>"name="exp" placeholder="Experiance">
					 </div>
					  <div class="form-group">
					 <input type="text" class="form-control" value="<?php echo $a1['dm_study']; ?>"name="Study" placeholder="Study "> 
					  </div>
                  </div>
                </div>
              </div>
              <div class="box-footer">
                <a href="doctor.php" class="btn btn-default">Cancel</a>
                <button type="submit" name="add" class="btn btn-info pull-right">Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>