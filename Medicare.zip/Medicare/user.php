<?php include 'header.php'; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>USER</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">Add New Details</h4>
              </div>
			  <form action="user_add.php" class="form-horizontal" method="post" role="form">
              <div class="modal-body">
                <div class="form-group">
                  <input type="text" class="form-control" name="user" placeholder="Enter User Name">
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="cnct" placeholder="Enter User contact number">
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="mail" placeholder="Enter User mail id">
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="psw" placeholder="Enter User password">
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="addr" placeholder="Enter User address">
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="bdate" placeholder="Enter User birthdate">
                </div>
				<div class="form-group">
				  <select class="form-control" name="role">
					<option selected disabled>Choose Role</option>
					<option value="Admin">Admin</option>
					<option value="Doctor">Doctor</option>
					<option value="Chemist">Chemist</option>
					<option value="User">User</option>
				  </select>
			  </div>
				 </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="add" class="btn btn-primary">Save changes</button>
              </div>
			  </form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
						  <th>#</th>
						  <th>Customer</th>
						  <th>Contact No</th> 
						  <th>Mail id</th>
						  <th>Address</th>
						  <th>Role</th>
						  <th>Birthdate</th>
						  <th>Action</th>
				</tr>
                </thead>
                <tbody>
			<?php
				$i=1;
				$user=mysqli_query($con, "select * from user_master");
				while($c1=mysqli_fetch_array($user))
				{
			?>
                <tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $c1['um_name']; ?></td>
					<td><?php echo $c1['um_cnct']; ?></td>
					<td><?php echo $c1['um_mail']; ?></td>
					<td><?php echo $c1['um_add']; ?></td>
					<td><?php echo $c1['um_role']; ?></td>
					<td><?php if($c1['um_bdate']!="0000-00-00"){echo date("M d, Y", strtotime($c1['um_bdate']));} ?></td>
					<td><a href="user_update.php?id=<?php echo $c1['um_id']; ?>" class="btn btn-info">Update</a><a href="user_del.php?id=<?php echo $c1['um_id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
			<?php
					$i++;
				}
			?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>