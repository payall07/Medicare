<?php include 'header.php'; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>Categories</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">Add New Details</h4>
              </div>
			  <form action="cat_add.php" class="form-horizontal" method="post" role="form">
              <div class="modal-body">
                <div class="form-group">
                  <input type="text" class="form-control" name="cat" placeholder="Enter Category Name">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="add" class="btn btn-primary">Save changes</button>
              </div>
			  </form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Categories</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
			<?php
				$i=1;
				$categories=mysqli_query($con, "select * from cat_master");
				while($cat=mysqli_fetch_array($categories))
				{
			?>
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $cat['cat_name']; ?></td>
                  <td><a href="cat_update.php?id=<?php echo $cat['cat_id']; ?>" class="btn btn-info">Update</a><a href="cat_del.php?id=<?php echo $cat['cat_id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
			<?php
					$i++;
				}
			?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>