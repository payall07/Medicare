<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$symptom=mysqli_query($con, "select * from symptom_master where sm_id=".$id);
	$s1=mysqli_fetch_array($symptom);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Symptoms Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <?php
				$id=$_REQUEST['id'];
				$query=mysqli_query($con,"SELECT * FROM `symptom_master` where sm_id=".$id);
				$rows = mysqli_fetch_array($query);
			?>
				<form role="form" action="symptom_update1.php?id=<?php echo $id;?>" method="post" id="popup-validation">
					<div class="col-lg-12">
					<div class="form-group">
					<label>Name</label>
				<input class="validate[required] form-control" name="name" value="<?php echo $rows['sm_name'];?>">
			</div>
				<div align="center">
				<button type="submit" name="submit_btn" class="btn btn-primary">Save Changes</button>
				<a href="symptoms.php" class="btn btn-danger">Go Back</a>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>