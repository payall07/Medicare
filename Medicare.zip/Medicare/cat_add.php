<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$cat=$_POST['cat'];
			mysqli_query($con, "INSERT INTO `cat_master`(`cat_name`) VALUES ('".$cat."')");
			header("location:cat.php");
		}
	}
	else
	{header("location:index.php");}
?>