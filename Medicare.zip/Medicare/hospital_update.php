<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$hos=mysqli_query($con, "SELECT * FROM `hospital_master` WHERE hm_id=".$id);
	$h1=mysqli_fetch_array($hos);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Hospital Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <form class="form-horizontal" action="hospital_update1.php?id=<?php echo $id; ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
<input type="text" class="form-control" value="<?php echo $h1['hm_name']; ?>" name="hname" placeholder="Enter hospital name">
<input type="text" class="form-control" value="<?php echo $h1['hm_cnct']; ?>" name="cnct" placeholder=	"Enter hospital contact">
<input type="text" class="form-control"  value="<?php echo $h1['hm_mail']; ?>"name="mail" placeholder="Enter hospital mail">
<input type="text" class="form-control" value="<?php echo $h1['hm_add']; ?>" name="add" placeholder="Enter hospital Address">
<input type="text" class="form-control" value="<?php echo $h1['hm_lat']; ?>" name="lat" placeholder="Enter hospital latitude">
<input type="text" class="form-control"  name="long" placeholder="Enter Chemist Long">
<input type="text" class="form-control"  value="<?php echo $h1['hm_desc']; ?>"name="desc" placeholder="Enter hospital Description">
<input type="text" class="form-control"  value="<?php echo $h1['hm_regdate']; ?>"name="regdate" placeholder="Enter hospital date">
                  </div>
                  </div>
                </div>
              <div class="box-footer">
                <a href="hospital.php" class="btn btn-default">Cancel</a>
                <button type="submit" name="add" class="btn btn-info pull-right">Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>