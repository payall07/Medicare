<?php
	include "connection.php";
	$name=$_POST['um_name'];
	$contact=$_POST['um_cnct'];
	$mail=$_POST['um_mail'];
	$pass=$_POST['um_psw'];
	$add=$_POST['um_add'];
	$bdate=$_POST['um_bdate'];
	
	$result=mysqli_query($con,"INSERT INTO `user_master`(`um_name`, `um_cnct`, `um_mail`, `um_psw`, `um_add`, `um_bdate`) VALUES ('".$name."','".$contact."','".$mail."','".$pass."','".$add."','".$bdate."')");
	$response=array();
	
	if($result)
	{ $response["success"]=1;}
	else
	{ $response["success"]=0;}
	echo json_encode($response);
?>