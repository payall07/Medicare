<?php
	require_once("db.php");
	if(!empty($_POST["sm_id"])) 
	{
		$query =mysqli_query($con,"SELECT * FROM city_master WHERE sm_id = '" . $_POST["sm_id"] . "'");
?>
		<option value="">Select city</option>
<?php
		while($row=mysqli_fetch_array($query)){
?>
		<option value="<?php echo $row["ct_id"]; ?>"><?php echo $row["ct_name"]; ?></option>
<?php
		}
	}
	if(!empty($_POST["ct_id"])) 
	{
		$query =mysqli_query($con,"SELECT * FROM area_master WHERE ct_id = '" . $_POST["ct_id"] . "'");
?>
		<option value="">Select Area</option>
<?php
		while($row=mysqli_fetch_array($query)){
?>
		<option value="<?php echo $row["am_id"]; ?>"><?php echo $row["am_name"]." - ".$row['am_pin']; ?></option>
<?php
		}
	}
?>
