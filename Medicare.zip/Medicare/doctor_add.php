<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$doc=$_POST['doc'];
			$spec=mysqli_real_escape_string($con, $_POST['spec']);
			$exp=$_POST['exp'];
			$study=mysqli_real_escape_string($con,$_POST['study']);
			mysqli_query($con, "INSERT INTO `doctor_master`(`dm_name`, `dm_spec`, `dm_exp`, `dm_study`) VALUES ('".$doc."','".$spec."','".$exp."','".$study."')")or die(mysqli_error($con));
			header("location:doctor.php");
		}
	}
	else
	{header("location:index.php");}
?>