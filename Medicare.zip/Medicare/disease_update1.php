<?php 
	include 'db.php';
	$id=$_REQUEST['id'];
	if(isset($_POST['submit_btn']))
	{
		$name=$_POST['name'];
		
		$query=mysqli_query($con, "UPDATE `disease_master` SET `dis_name`='".$name."' WHERE dis_id=".$id);
		
		header("location:disease.php");
	}
?>