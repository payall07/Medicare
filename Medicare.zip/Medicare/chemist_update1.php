<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$name=$_POST['cname'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$add=mysqli_real_escape_string($con, $_POST['add']);
			$lat=$_POST['lat'];
			$long=$_POST['long'];
			$desc=mysqli_real_escape_string($con, $_POST['desc']);
			$reg=$_POST['regdate'];
			$logo=$_FILES['img']['name'];
						
			mysqli_query($con, "UPDATE `chemist_master` SET `cm_name`='".$name."',`cm_cnct`='".$cnct."',`cm_mail`='".$mail."',`cm_add`='".$add."',`cm_lat`='".$lat."',`cm_long`='".$long."',`cm_desc`='".$desc."',`cm_regdate`='".$reg."',`cm_logo`='".$logo."' WHERE `cm_id`=".$id); or die(mysqli_error($con));
			
			
			header("location:chemist.php");
			
		}
	}
	else
	{header("location:index.php");}
?>