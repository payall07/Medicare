<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{   
			$id=$_REQUEST['id'];
			$doc=$_POST['doc'];
			$spec=mysqli_real_escape_string($con, $_POST['spec']);
			$exp=$_POST['exp'];
			$study=mysqli_real_escape_string($con, $_POST['study']);
			mysqli_query($con, "UPDATE `doctor_master` SET `dm_name`='".$doc."',`dm_spec`='".$spec."',`dm_exp`='".$exp."',`dm_study`='".$study."' WHERE `dm_id`=".$id);
			header("location:doctor.php");
		}
	}
	else
	{header("location:index.php");}
?>