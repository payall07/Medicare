<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$p1=$_POST['product'];
			$desc=$_POST['desc'];
			$price=$_POST['price'];
			$type=$_POST['type'];
			
			
			mysqli_query($con, "UPDATE `product_master` SET `pm_name`='".$p1."',`pm_desc`='".$desc."',`pm_price`='".$price."',`pm_type`='".$type."' WHERE `pm_id`=".$id);
			header("location:product.php");
		}
		
	}
	else
	{header("location:index.php");}
?>