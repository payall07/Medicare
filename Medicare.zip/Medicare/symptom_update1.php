<?php 
	include 'db.php';
	$id=$_REQUEST['id'];
	if(isset($_POST['submit_btn']))
	{
		$name=$_POST['name'];
		
		$query=mysqli_query($con, "UPDATE `symptom_master` SET `sm_name`='".$name."' WHERE sm_id=".$id);
		
		header("location:symptoms.php");
	}
?>