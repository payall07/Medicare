<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$state=$_POST['state'];
			$city=$_POST['city'];
			mysqli_query($con, "INSERT INTO `city_master`(`sm_id`, `ct_name`) VALUES('".$state."', '".$city."')");
			header("location:city.php");
		}
	}
	else
	{header("location:index.php");}
?>