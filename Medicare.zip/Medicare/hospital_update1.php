<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$hos=$_POST['hname'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$add=mysqli_real_escape_string($con, $_POST['add']);
			$lat=$_POST['lat'];
			$long=$_POST['long'];
			$desc=mysqli_real_escape_string($con, $_POST['desc']);
			$reg=$_POST['regdate'];
			
			mysqli_query($con, "UPDATE `hospital_master` SET `hm_name`='".$hos."',`hm_cnct`='".$cnct."',`hm_mail`='".$mail."',`hm_add`='".$add."',`hm_lat`='".$lat."',`hm_long`='".$long."',`hm_desc`='".$desc."',`hm_regdate`='".$reg."' WHERE `hm_id`=".$id);
			
			header("location:hospital.php");
		}
	}
	else
	{header("location:index.php");}
?>