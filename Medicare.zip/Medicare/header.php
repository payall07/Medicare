log<?php
	session_start();
	if(!isset($_SESSION['userid']))
	{header("location:index.php");}
	else
	{
		include 'db.php';
		$userid=$_SESSION['userid'];
		$logindata=mysqli_query($con, "select * from user_master where um_id=".$userid);
		$log=mysqli_fetch_array($logindata);
	}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Medicare | Dashboard</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/bootstrap-material-design.min.css">
  <link rel="stylesheet" href="dist/css/ripples.min.css">
  <link rel="stylesheet" href="dist/css/MaterialAdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/all-md-skins.min.css">
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">
  <header class="main-header">
    <a href="dashboard.php" class="logo">
      <span class="logo-mini"><b>Medi</b></span>
      <span class="logo-lg"><b>Medi</b>Care</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">4</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 4 messages</li>
              <li>
			  	<ul class="menu">
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user-160x160.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Support Team
                        <small><i class="fa fa-clock-o"></i> 5 mins</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">See All Messages</a></li>
            </ul>
          </li>
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $log['um_name']; ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
			  	<?php if($log['um_img']!="") { ?>
                <img src="<?php echo $log['um_img']; ?>" class="img-circle" alt="<?php echo $log['um_name']; ?>">
				<?php } else { ?>
				<img src="dist/img/avatar5.png" class="img-circle" alt="<?php echo $log['um_name']; ?>">
				<?php } ?>
                <p><?php echo $log['um_name']; ?>
                  <small>Member since <?php echo date("M, Y", strtotime($log['um_regdate'])); ?></small>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
		  <li>&nbsp;&nbsp;</li>
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active"><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        
		<!--/*<li class="treeview">	
          <a href="#"><i class="fa fa-table"></i> <span>User</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
			<li><a href="chemist.php"><i class="fa fa-list"></i><span>Chemist</span></a></li>
			<li><a href="user.php"><i class="fa fa-list"></i><span>Customer</span></a></li>
			<li><a href="doctor.php"><i class="fa fa-list"></i><span>Doctor</span></a></li>
          </ul>
        </li>*/-->
		<?php
		if ( $log['um_role'] == 'Chemist' )
        {
		?>
			<li><a href="cat.php"><i class="fa fa-list"></i><span>Categories</span></a></li>
            <li><a href="product.php"><i class="fa fa-list"></i><span>Product</span></a></li>
			<li><a href="chemist.php"><i class="fa fa-list"></i><span>Chemist</span></a></li>
		<?php
        }
		
		else if ( $log['um_role'] == 'Doctor' )
		{?>
			<li><a href="doctor.php"><i class="fa fa-list"></i><span>Doctor</span></a></li>
			<li><a href="hospital.php"><i class="fa fa-list"></i><span>Hospital</span></a></li>
			<?php
		}
		
		
		else
		{
		?>
			<li><a href="cat.php"><i class="fa fa-list"></i><span>Categories</span></a></li>
			<li><a href="product.php"><i class="fa fa-list"></i><span>Product</span></a></li>
			<li><a href="User.php"><i class="fa fa-list"></i><span>User</span></a></li>
			<li><a href="symptoms.php"><i class="fa fa-list"></i> Symptoms</a></li>
		    <li><a href="disease.php"><i class="fa fa-list"></i> Diseases</a></li>
			<li><a href="sym_dis.php"><i class="fa fa-list"></i> Symptom-Disease</a></li>
            <li><a href="chemist.php"><i class="fa fa-list"></i><span>Chemist</span></a></li>
			<li><a href="doctor.php"><i class="fa fa-list"></i><span>Doctor</span></a></li>
			<li><a href="hospital.php"><i class="fa fa-list"></i><span>Hospital</span></a></li>
			<li><a href="area.php"><i class="fa fa-list"></i><span>Area</span></a></li>
			<li><a href="city.php"><i class="fa fa-list"></i><span>City</span></a></li>
			<li><a href="state.php"><i class="fa fa-list"></i><span>State</span></a></li>
			
			<?php
		} 
		?>
      </ul>
	</section>
  </aside>