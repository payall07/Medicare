<?php
	include 'header.php';
	$id=$_REQUEST['id'];
	$city=mysqli_query($con, "SELECT * FROM `area_master` WHERE am_id=".$id);
	$c1=mysqli_fetch_array($city);
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>City Details Update</h1>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info">
            <form class="form-horizontal" action="area_update1.php?id=<?php echo $id; ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <div class="col-sm-12">
                     <select class="form-control" name="city">
						<option selected disabled>Select City</option>
					<?php
						$state=mysqli_query($con, "select * from city_master");
						while($st=mysqli_fetch_array($state))
						{
					?>
						<option <?php if($st['ct_id']==$c1['ct_id']) {echo "selected";}?> value="<?php echo $st['ct_id']; ?>"><?php echo $st['ct_name']; ?></option>
					<?php
						}
					?>
					  </select>
                  </div>
				  <div class="col-sm-6">
                    <input type="text" class="form-control" value="<?php echo $c1['am_name']; ?>" name="cname" placeholder="Enter city name">
                  </div>
				  <div class="col-sm-6">
                    <input type="text" class="form-control" value="<?php echo $c1['am_pin']; ?>" name="pin" placeholder="Enter city name">
                  </div>
                </div>
              </div>
              <div class="box-footer">
                <a href="area.php" class="btn btn-default">Cancel</a>
                <button type="submit" name="add" class="btn btn-info pull-right">Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<script src="dist/js/adminlte.min.js"></script>
<script src="dist/js/demo.js"></script>