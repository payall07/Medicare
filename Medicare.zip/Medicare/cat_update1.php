<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$cat=$_POST['cat'];
			mysqli_query($con, "UPDATE `cat_master` SET `cat_name`='".$cat."' WHERE `cat_id`=".$id);
			header("location:cat.php");
		}
	}
	else
	{header("location:index.php");}
?>