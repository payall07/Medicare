<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$id=$_REQUEST['id'];
			$state=$_POST['state'];
			$city=$_POST['cname'];
			mysqli_query($con, "UPDATE `city_master` SET `sm_id`='".$state."', `ct_name`='".$city."' WHERE `ct_id`=".$id);
			header("location:city.php");
		}
	}
	else
	{header("location:index.php");}
?>