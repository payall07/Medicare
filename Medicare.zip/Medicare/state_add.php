<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$a1=$_POST['state'];
			mysqli_query($con, "INSERT INTO `state_master`(`sm_name`) VALUES ('".$a1."')");
			header("location:state.php");
		}
	}
	else
	{header("location:index.php");}
?>