<?php 
	include 'connection.php';
	$response=array();
	
	$symp=explode(", ", $_REQUEST['symp']);
	foreach($symp as $s)
	{
		$data=mysqli_query($con, "select * from symptom_master where sm_name='".$s."'"); $row=mysqli_fetch_array($data);
		$sdis=mysqli_query($con, "select * from sdis_master s, disease_master d where d.dis_id=s.dis_id and s.sm_id=".$row['sm_id']);
		while($sdi=mysqli_fetch_array($sdis))
		{$dis[]=$sdi['dis_name']." ";
		}
	}
	$arr = $dis;
	$n = sizeof($arr) / sizeof($arr[0]); 
	function mostFrequent( $arr, $n) 
	{
		sort($arr); 
		sort($arr , $n); 
	  
	  	$max_count = 1;  
		$res = $arr[0];  
		$curr_count = 1; 
		for ($i = 1; $i < $n; $i++)  
		{ 
			if ($arr[$i] == $arr[$i - 1]) 
				$curr_count++; 
			else 
			{ 
				if ($curr_count > $max_count) 
				{ 
					$max_count = $curr_count; 
					$res = $arr[$i - 1]; 
				} 
				$curr_count = 1; 
			} 
		} 
	  	if ($curr_count > $max_count) 
		{ 
			$max_count = $curr_count; 
			$res = $arr[$n - 1]; 
		} 
	  	return $res; 
	}
	$a=mostFrequent($arr, $n);
	if($a!="")
	{
		$response["data"]=$a;
		$response["success"] = 1;
		$response["message"] = "Disease found";
	}
	else
	{
		$response["success"] = 0;
	    $response["message"] = "No disease found";
	}
	echo json_encode($response);
?>