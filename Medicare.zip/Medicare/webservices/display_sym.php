<?php 
	
	include 'connection.php';
	
	$response=array();
	
	$result = mysqli_query($con,"SELECT sm_name, sm_id FROM `symptom_master`") or die(mysqli_error($con));
	
	if (mysqli_num_rows($result) > 0) {
	
	 $response["symptoms"] = array();
	 
	 while ($row = mysqli_fetch_array($result)) {
        $response["symptoms"][]=$row;
	}
	
	$response["success"] = 1;
	
	echo json_encode($response);
} else {

		$response["success"] = 0;
    $response["message"] = "No disease found";

    echo json_encode($response);
	}
?>