<?php 
	
	include 'connection.php';
	$user =$_REQUEST['user'];
	//$doctor =$_REQUEST['doctorid'];
	$response=array();
	
	$result = mysqli_query($con,"SELECT * FROM app_master a, doctor_master d , hospital_master h where d.dm_id=a.dm_id and d.hm_id=h.hm_id and a.um_id=".$user) or die(mysqli_error($con));
	
	if (mysqli_num_rows($result) > 0) {
	
	 $response["appointment"] = array();
	 
	 while ($row = mysqli_fetch_array($result)) {
        $response["appointment"][]=$row;
	}
	
	$response["success"] = 1;
	
	echo json_encode($response);
} else {

		$response["success"] = 0;
    $response["message"] = "No disease found";

    echo json_encode($response);
	}
?>