<?php
	include "connection.php";
	
	$Contact = $_REQUEST['userid'];
	$Password = $_REQUEST['password'];
//	$Role = $_REQUEST["role"];
		
	$R=mysqli_query($con, "SELECT * FROM `user_master` WHERE um_cnct = '".$Contact."' or  um_mail='".$Contact."' and um_psw = '".$Password."'");
	$response['image'] = array();
	
	if($R)
	{
		while($p=mysqli_fetch_assoc($R))
		{
			$response['image'][]=$p;
		}
		
		$response['success']=1;
		$response['message']="successfully Data Received";
	}
	else
	{
		$response['success']=0;
		$response['message']="Data not found";
	}
	
	echo json_encode($response);
?>