package com.example.punjal.clothe_shop;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Cat_list extends AppCompatActivity {

    private ProgressDialog pDialog;


    JSONParser jParser = new JSONParser();
    ArrayList<HashMap<String, String>> clothlist;


    private static String url_all_products = "http://192.168.43.63/gst/webservices/alldata.php";

   // private static String url_product_data = "http://192.168.43.63/gst/webservices/get_data.php";


    String Scat_id, Sdm_id, Scat_name ;
    ViewGroup parent;

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_PRODUCTS = "userdata";
    private static final String TAG_cat_id = "cat_id";
    private static final String TAG_dm_id = "dm_id";
    private static final String TAG_cat_name = "cat_name";

    JSONArray products = null;

    ListView list;
    String dm_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_list);

        Intent intent = getIntent();
        dm_id = intent.getStringExtra("dm_id");
        Log.d("department id", dm_id);


        clothlist = new ArrayList<HashMap<String, String>>();
        new LoadAllProducts().execute();
        list = (ListView) findViewById(R.id.cllist);

    }

    public class LoadAllProducts extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Cat_list.this);
            pDialog.setMessage("Loading clothes Please wait...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }


        protected String doInBackground(String... args) {
            List<NameValuePair> params = new ArrayList<NameValuePair>();

            params.add(new BasicNameValuePair("dm_id", dm_id));

            JSONObject json = jParser.makeHttpRequest(url_all_products, "GET", params);
            Log.d("Clothe List: ", json.toString());


            try {

                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {

                    products = json.getJSONArray(TAG_PRODUCTS);
                    for (int i = 0; i < products.length(); i++) {
                        JSONObject c = products.getJSONObject(i);
                        Scat_id = c.getString(TAG_cat_id);
                        Sdm_id = c.getString(TAG_dm_id);
                        Scat_name = c.getString(TAG_cat_name);

                        HashMap<String, String> map = new HashMap<String, String>();

                        map.put(TAG_cat_id, Scat_id);
                        Log.d("TAG_cat_id", Scat_id);
                        map.put(TAG_dm_id, Sdm_id);
                        Log.d("TAG_dm_id", Sdm_id);
                        map.put(TAG_cat_name, Scat_name);
                        Log.d("TAG_cat_name", Scat_name);
                        clothlist.add(map);
                    }
                }
                else {

                    Intent i = new Intent(getApplicationContext(),
                            Details_page.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pDialog.dismiss();

            Cat_list.List_Adapter adapter = new
                    Cat_list.List_Adapter(getApplicationContext(), clothlist);

            list.setAdapter(adapter);
        }
    }

    public class List_Adapter extends BaseAdapter {

        Context context;
        LayoutInflater inflater;
        ArrayList<HashMap<String, String>> data;
        HashMap<String, String> result = new HashMap<String, String>();

        public List_Adapter(Context context, ArrayList<HashMap<String, String>> arraylist) {

            this.context = context;
            this.data = arraylist;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @SuppressLint("WrongViewCast")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
                // TODO Auto-generated method stub
                final TextView sname;
                final CardView cat;
                final TextView sid;
                final TextView sprice;
            final ImageView imageView;

                final String name;
                final String desc;
                final String price;
                final String id;
                final String image;
                final String Surl;
                final String cat_id ;
                final int MAX_WIDTH=1024;
                final int MAX_HEIGHT=768;

                int size = (int) Math.ceil(Math.sqrt(MAX_WIDTH * MAX_HEIGHT));
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View itemView = inflater.inflate(R.layout.list_cat, parent, false);
                result = data.get(position);

                sname = (TextView) itemView.findViewById(R.id.txt_cat);
                cat=(CardView)findViewById(R.id.cat_card_view);
                imageView = (ImageView)itemView.findViewById(R.id.img_dept);

                sname.setText(result.get(TAG_cat_name));
                cat_id=result.get("cat_id");

//                name = result.get(TAG_NAME);
//                price = result.get(TAG_PRICE);
//                desc = result.get(TAG_DESC);
//                id = result.get(TAG_PID);



            sname.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), Productlist.class);
                    i.putExtra("cat_id", cat_id);

                    startActivity(i);

                }
            });

            return itemView;
        }
    }
}





