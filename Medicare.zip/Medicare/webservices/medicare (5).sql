-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2019 at 07:28 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medicare`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_master`
--

CREATE TABLE IF NOT EXISTS `app_master` (
  `am_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `dm_id` int(10) NOT NULL,
  `am_title` varchar(254) NOT NULL,
  `am_desc` text NOT NULL,
  `am_appdate` datetime NOT NULL,
  `am_date` datetime NOT NULL,
  PRIMARY KEY (`am_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `app_master`
--

INSERT INTO `app_master` (`am_id`, `um_id`, `dm_id`, `am_title`, `am_desc`, `am_appdate`, `am_date`) VALUES
(1, 14, 6, 'jask dhfjsh kjdfh kjasdf', 'askjdf lkasdj flkjasdlkfdj asdlkdfj lkasdj flkasdjflkjasdldkfj asdlkjdf lkasdj flk jas dlkfj asdlkfj lkasdjflkasdj flkjas dlkfj asdlkf jlkasdj flkasdj dflkj sf jlsad jflkjas lfdkj sa', '2017-11-27 13:31:00', '2017-11-26 16:41:00');

-- --------------------------------------------------------

--
-- Table structure for table `area_master`
--

CREATE TABLE IF NOT EXISTS `area_master` (
  `am_id` int(10) NOT NULL AUTO_INCREMENT,
  `ct_id` int(10) NOT NULL,
  `am_name` varchar(254) NOT NULL,
  `am_pin` int(10) NOT NULL,
  PRIMARY KEY (`am_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `area_master`
--

INSERT INTO `area_master` (`am_id`, `ct_id`, `am_name`, `am_pin`) VALUES
(2, 1, 'Patel Colony', 388001),
(3, 2, 'shravan chokdi', 392001),
(4, 2, 'saktinath', 392001),
(5, 2, 'pachbattiii', 392001);

-- --------------------------------------------------------

--
-- Table structure for table `cart_master`
--

CREATE TABLE IF NOT EXISTS `cart_master` (
  `crt_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `pm_id` int(10) NOT NULL,
  `crt_qty` int(3) NOT NULL,
  `crt_date` date NOT NULL,
  PRIMARY KEY (`crt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cat_master`
--

CREATE TABLE IF NOT EXISTS `cat_master` (
  `cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(254) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cat_master`
--

INSERT INTO `cat_master` (`cat_id`, `cat_name`) VALUES
(3, ' medicine'),
(4, 'Ayush'),
(5, 'Fitness'),
(6, 'Family Care'),
(7, 'Life Style');

-- --------------------------------------------------------

--
-- Table structure for table `chemist_master`
--

CREATE TABLE IF NOT EXISTS `chemist_master` (
  `cm_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `cm_name` varchar(254) NOT NULL,
  `cm_cnct` varchar(20) NOT NULL,
  `cm_mail` varchar(70) NOT NULL,
  `cm_add` text NOT NULL,
  `am_id` int(10) NOT NULL,
  `cm_lat` varchar(15) NOT NULL,
  `cm_long` varchar(15) NOT NULL,
  `cm_desc` text NOT NULL,
  `cm_regdate` datetime NOT NULL,
  `cm_logo` varchar(254) NOT NULL,
  PRIMARY KEY (`cm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `chemist_master`
--

INSERT INTO `chemist_master` (`cm_id`, `um_id`, `cm_name`, `cm_cnct`, `cm_mail`, `cm_add`, `am_id`, `cm_lat`, `cm_long`, `cm_desc`, `cm_regdate`, `cm_logo`) VALUES
(1, 0, 'Nilkanth medical store', '9876542123', 'asdf@asd.c', 'sadfasdf;lkasdjfl jsadklf lksadj flkasdj flkj asdlkfj ', 2, 'aslkdj f', '73.2545525', '23.254878', '2019-02-21 14:19:22', 'images/chemist/IMG-20180117-WA0000.jpg'),
(2, 0, 'Nilkanth medical store', '9876542123', 'asdf@asd.c', 'sadfasdf;lkasdjfl jsadklf lksadj flkasdj flkj asdlkfj ', 0, 'aslkdj f', '', '', '2019-03-05 12:36:12', 'images/chemist/a.png'),
(3, 0, 'Payal Patel', '9876542123', 'nil@gmail.com', '', 1, '', '', 'aklsdj flkfaj sdlf jasdlkdfj laksd jfjlkasdj flkasjdfd', '2019-03-05 12:50:44', 'images/chemist/a.png');

-- --------------------------------------------------------

--
-- Table structure for table `city_master`
--

CREATE TABLE IF NOT EXISTS `city_master` (
  `ct_id` int(10) NOT NULL AUTO_INCREMENT,
  `sm_id` int(10) NOT NULL,
  `ct_name` varchar(254) NOT NULL,
  PRIMARY KEY (`ct_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `city_master`
--

INSERT INTO `city_master` (`ct_id`, `sm_id`, `ct_name`) VALUES
(1, 1, 'Anand'),
(2, 1, 'bharuch'),
(3, 1, 'vadodra'),
(4, 1, 'surat'),
(5, 2, 'jaipur'),
(6, 2, 'udaipur');

-- --------------------------------------------------------

--
-- Table structure for table `disease_master`
--

CREATE TABLE IF NOT EXISTS `disease_master` (
  `dis_id` int(10) NOT NULL AUTO_INCREMENT,
  `dis_name` varchar(254) NOT NULL,
  PRIMARY KEY (`dis_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `disease_master`
--

INSERT INTO `disease_master` (`dis_id`, `dis_name`) VALUES
(4, 'Dengue                                                                                                                                                '),
(6, 'Malaria'),
(8, 'Typhoid'),
(9, 'Asthma'),
(10, 'Aids'),
(11, 'Bacterial Meningitis'),
(12, 'Food poison'),
(13, 'Senetics of Heart'),
(14, 'Gout'),
(15, 'Bird flu'),
(16, 'Red blood disorder'),
(17, 'White blood disorder'),
(18, 'Platelet disorders'),
(19, 'Cancer'),
(20, 'Chikenpox'),
(21, 'Cholera'),
(22, 'Chronic gastritis'),
(23, 'Diabetes'),
(24, 'Animal bites infection'),
(25, 'Ear infection'),
(26, 'Outer ear infection'),
(27, 'Flu'),
(28, 'Gonorrehea'),
(29, 'Heat stroke'),
(30, 'Heat exhaustion'),
(31, 'Hepatitis'),
(32, 'High blood pressure'),
(33, 'Jaundice'),
(34, 'Kidney failure'),
(35, 'Lead poisoning'),
(36, 'Fatty liver'),
(37, 'Liver pain'),
(39, 'Monkeypox'),
(40, 'Nutritional deficiencies (Malnutrition)'),
(41, 'Pneumonia'),
(42, 'Back pain'),
(43, 'Chest pain'),
(44, 'Gas pain'),
(45, 'Goiter'),
(46, 'Hypothyroidism'),
(47, 'Thyroid'),
(48, 'Thalassemia'),
(49, 'Alcoholic ketoacidosis'),
(50, 'Cirrhosis'),
(51, 'Drug allergy'),
(52, 'Leukemia'),
(53, 'Addisonian crisis (Acute Adrenal Crisis)'),
(54, 'Pancreatic cancer'),
(55, 'Underactive Pituitary Gland (Hypopituitarism)'),
(56, 'Ectopic pregnancy'),
(57, 'Ovarian cancer'),
(58, 'PMS (Premenstrual Syndrome)'),
(59, 'Giardiasis'),
(60, 'Viral gastroenteritis'),
(61, 'Acid reflux'),
(62, 'Gastritis'),
(63, 'Erosive gastritis'),
(64, 'Irritable bowel syndrome (IBS)'),
(65, 'Ulcerative colitis'),
(66, 'Peptic Ulcer'),
(67, ''),
(68, '');

-- --------------------------------------------------------

--
-- Table structure for table `dis_doc`
--

CREATE TABLE IF NOT EXISTS `dis_doc` (
  `d_d_id` int(10) NOT NULL AUTO_INCREMENT,
  `dis_id` int(100) NOT NULL,
  `dm_id` int(100) NOT NULL,
  PRIMARY KEY (`d_d_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `dis_doc`
--

INSERT INTO `dis_doc` (`d_d_id`, `dis_id`, `dm_id`) VALUES
(1, 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_master`
--

CREATE TABLE IF NOT EXISTS `doctor_master` (
  `dm_id` int(10) NOT NULL AUTO_INCREMENT,
  `hm_id` int(11) NOT NULL,
  `um_id` int(10) NOT NULL,
  `dm_name` varchar(254) NOT NULL,
  `dm_spec` varchar(254) NOT NULL,
  `dm_exp` varchar(3) NOT NULL,
  `dm_study` varchar(254) NOT NULL,
  `dm_desc` text NOT NULL,
  PRIMARY KEY (`dm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `doctor_master`
--

INSERT INTO `doctor_master` (`dm_id`, `hm_id`, `um_id`, `dm_name`, `dm_spec`, `dm_exp`, `dm_study`, `dm_desc`) VALUES
(6, 0, 13, 'mr. Bharat Joshi', 'heart specialist', '8', 'complete a degree in medicine recognised by the General Medical Council (GMC).', ''),
(7, 0, 0, 'Nishi mehta', 'ENT Specialist', '5', 'specialized coursework in otolaryngology', ''),
(8, 0, 0, 'miss. hema rana', 'dentist', '3', 'Dergee of DDS (Doctor of Dental Surgery)', '');

-- --------------------------------------------------------

--
-- Table structure for table `doc_hos`
--

CREATE TABLE IF NOT EXISTS `doc_hos` (
  `dh_id` int(10) NOT NULL AUTO_INCREMENT,
  `dm_id` int(10) NOT NULL,
  `hm_id` int(10) NOT NULL,
  `dh_day` varchar(3) NOT NULL,
  `dh_stime` varchar(9) NOT NULL,
  `dh_etime` varchar(9) NOT NULL,
  PRIMARY KEY (`dh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `history_master`
--

CREATE TABLE IF NOT EXISTS `history_master` (
  `his_id` int(10) NOT NULL AUTO_INCREMENT,
  `his_name` varchar(254) NOT NULL,
  PRIMARY KEY (`his_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `hospital_master`
--

CREATE TABLE IF NOT EXISTS `hospital_master` (
  `hm_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `hm_name` varchar(254) NOT NULL,
  `hm_cnct` varchar(20) NOT NULL,
  `hm_mail` varchar(70) NOT NULL,
  `hm_add` text NOT NULL,
  `am_id` int(10) NOT NULL,
  `hm_lat` varchar(15) NOT NULL,
  `hm_long` varchar(15) NOT NULL,
  `hm_desc` text NOT NULL,
  `hm_regdate` datetime NOT NULL,
  `hm_logo` varchar(254) NOT NULL,
  PRIMARY KEY (`hm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `hospital_master`
--

INSERT INTO `hospital_master` (`hm_id`, `um_id`, `hm_name`, `hm_cnct`, `hm_mail`, `hm_add`, `am_id`, `hm_lat`, `hm_long`, `hm_desc`, `hm_regdate`, `hm_logo`) VALUES
(4, 0, 'Civil hospital', '9876542123', 'civil@asd.c', 'Civil Hospital in Petlad Road, Anand-Kheda - 387000. ', 0, 'aslkdj f', '', 'This is a government hospital.', '2018-12-20 17:15:45', 'images/hospital/images (1).png'),
(5, 0, 'zudas', '9835672901', 'Zudas@gmail.com', 'Zydus Hospitals & Healthcare Research Pvt. Ltd., Anand-Lambhvel Road, Anand - 388001, Gujarat, India.', 0, 'aslkdj f', 'salkd f', 'To be a leading provider in healthcare service delivery to the community. We shall achieve 1500 beds under our management by the year 2020 and become a most preferred destination for comprehensive medical care and treatment.', '2019-02-20 13:39:06', 'images/hospital/Best-Hospital-in-Gujarat-Zydus-Hospital.jpg'),
(6, 0, 'krishna', '9876542123', 'nil@gmail.com', 'sadfasdf;lkasdjfl jsadklf lksadj flkasdj flkj asdlkfj ', 0, 'aslkdj f', '73.2545525', 'aklsdj flkfaj sdlf jasdlkdfj laksd jfjlkasdj flkasjdfd', '2019-04-08 12:11:42', 'images/hospital/shree_krishana_hospital.png'),
(14, 0, 'IRIS hospital', '9632548710', 'iris@gmail.com', 'Lambhvel Road, Anand - 388001 India.', 1, '', '', 'The IRIS hospital is a 100 bedded hospital located in Anand city. It is away from the stuffy and noisy environment of the city. The Hospital is spread around a 3000 square meters land', '2019-04-08 14:21:41', 'images/hospital/logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `image_master`
--

CREATE TABLE IF NOT EXISTS `image_master` (
  `im_id` int(10) NOT NULL AUTO_INCREMENT,
  `pm_id` int(10) NOT NULL,
  `im_path` varchar(254) NOT NULL,
  PRIMARY KEY (`im_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE IF NOT EXISTS `product_master` (
  `pm_id` int(10) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL,
  `cm_id` int(10) NOT NULL,
  `pm_name` varchar(254) NOT NULL,
  `pm_desc` varchar(1000) NOT NULL,
  `pm_price` varchar(10) NOT NULL,
  `pm_type` varchar(254) NOT NULL,
  PRIMARY KEY (`pm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`pm_id`, `cat_id`, `cm_id`, `pm_name`, `pm_desc`, `pm_price`, `pm_type`) VALUES
(9, 0, 0, 'Peracitamol', 'Paracetamol is used to temporarily relieve fever and mild to moderate pain such as muscle ache, headache, toothache, arthritis and backache.', '20', 'Medicine'),
(11, 0, 0, 'Himalaya Facewash', 'Himalaya''s Purifying Neem Face Wash is a soap-free, herbal formulation that cleans impurities and helps clear pimples. A natural blend of Neem and Turmeric bring together their antibacterial and antifungal properties to prevent the recurrence of acne over time.', '500', 'life style'),
(12, 7, 0, 'Himalaya Facewash', 'Himalaya''s Purifying Neem Face Wash is a soap-free, herbal formulation that cleans impurities and helps clear pimples. A natural blend of Neem and Turmeric bring together their antibacterial and antifungal properties to prevent the recurrence of acne over time.', '50', 'life style'),
(13, 3, 0, 'paracetamol', 'Medomol 500 MG Tablet is used to temporarily relieve fever and mild to moderate pain such as muscle ache, headache, toothache, arthritis, and backache. This medicine should be used with caution in patients with liver diseases due to the increased risk of severe adverse effects.', '500', 'medicine'),
(14, 0, 0, 'dampi', 'Medomol 500 MG Tablet is used to temporarily relieve fever and mild to moderate pain such as muscle ache, headache, toothache, arthritis, and backache. This medicine should be used with caution in patients with liver diseases due to the increased risk of severe adverse effects.', '50', 'medicine');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_master`
--

CREATE TABLE IF NOT EXISTS `purchase_master` (
  `pur_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `pm_id` int(10) NOT NULL,
  `pur_qty` int(3) NOT NULL,
  `pur_price` varchar(10) NOT NULL,
  `pur_date` date NOT NULL,
  PRIMARY KEY (`pur_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sdis_master`
--

CREATE TABLE IF NOT EXISTS `sdis_master` (
  `s_dis_id` int(10) NOT NULL AUTO_INCREMENT,
  `dis_id` int(10) NOT NULL,
  `sm_id` int(10) NOT NULL,
  PRIMARY KEY (`s_dis_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sdis_master`
--

INSERT INTO `sdis_master` (`s_dis_id`, `dis_id`, `sm_id`) VALUES
(3, 8, 6),
(4, 8, 7),
(5, 8, 8),
(6, 8, 9),
(7, 9, 8),
(8, 9, 11),
(9, 9, 10),
(10, 9, 5),
(11, 9, 104),
(12, 10, 13),
(13, 10, 8),
(14, 10, 14),
(15, 10, 24),
(16, 10, 105);

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE IF NOT EXISTS `state_master` (
  `sm_id` int(10) NOT NULL AUTO_INCREMENT,
  `sm_name` varchar(254) NOT NULL,
  PRIMARY KEY (`sm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`sm_id`, `sm_name`) VALUES
(1, 'Gujarat'),
(2, 'Rajasthan'),
(3, 'Bihar'),
(4, 'maharastra');

-- --------------------------------------------------------

--
-- Table structure for table `symptom_master`
--

CREATE TABLE IF NOT EXISTS `symptom_master` (
  `sm_id` int(10) NOT NULL AUTO_INCREMENT,
  `sm_name` varchar(254) NOT NULL,
  PRIMARY KEY (`sm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=107 ;

--
-- Dumping data for table `symptom_master`
--

INSERT INTO `symptom_master` (`sm_id`, `sm_name`) VALUES
(2, 'Vomiting'),
(3, 'Body Pain'),
(5, 'Cough'),
(6, 'Weakness'),
(7, 'Abdominal Pain'),
(8, 'Headache'),
(9, 'Constipation'),
(10, 'Chest Pain'),
(11, 'Shortness of Breath'),
(12, 'Cold'),
(13, 'Fever'),
(14, 'Body rush'),
(15, 'Muscle pain'),
(16, 'Joint Pain'),
(17, 'Cold hands or feet'),
(18, 'Diarrhea'),
(19, 'Mild fever'),
(20, 'Cyanosis'),
(21, 'Stiffness in the joint'),
(22, 'Fever (over 100.4Â°F or 38Â°C)'),
(23, 'Runny nose'),
(24, 'Sore throat'),
(25, 'Fast heartbeat'),
(26, 'Fatigue'),
(27, 'Chronic infections'),
(28, 'Unexplained weight loss'),
(29, 'Malaise'),
(30, 'Nose Bleeding'),
(31, 'Bleeding gums'),
(32, 'Blood in urine'),
(33, 'Rectal bleeding'),
(34, 'Persistent back pain'),
(35, 'Loss of appetite'),
(36, 'Dehydration'),
(37, 'Indigestion'),
(38, 'Skin rashes'),
(39, 'Increased thirst'),
(40, 'Increased hunger'),
(41, 'Increased urination'),
(42, 'Blurry vision'),
(43, 'Loss of sensation around the bite'),
(44, 'Pus oozing from the wound'),
(45, 'Tenderness in areas near the bite'),
(46, 'Red streaks near the bite'),
(47, 'Dizziness'),
(48, 'Nausea'),
(49, 'Dry cough'),
(50, 'Swelling or Redness at the opening of the penis'),
(51, 'Swelling or pain in the testicles'),
(52, 'Moist skin'),
(53, 'Increased heavy sweating'),
(54, 'Possible fainting'),
(55, 'Dark urine'),
(56, 'Pale stool'),
(57, 'Yellow skin and eyes'),
(58, 'Itchiness'),
(59, 'Reduced amount of urine'),
(60, 'Swelling of your legs'),
(61, 'Seizures'),
(62, 'Aggressive behavior'),
(63, 'Sleep problems'),
(64, 'Irritability'),
(65, 'High blood pressure'),
(66, 'Memory loss'),
(67, 'Anemia'),
(68, 'Kidney dysfunction'),
(69, 'Physical weakness'),
(70, 'Confusion'),
(71, 'Itchy skin'),
(72, 'Convulsions'),
(73, 'Pustules develops most often on the face and chest'),
(74, 'Hair loss'),
(75, 'Sleepiness'),
(76, 'Depression'),
(77, 'Poor concentration'),
(78, 'Sweating'),
(79, 'Weight gain'),
(80, 'Slowed heart rate'),
(81, 'Elevated blood cholesterol'),
(82, 'Thinning hair'),
(83, 'High pulse rate'),
(84, 'Nervousness'),
(85, 'Increased appetite'),
(86, 'Tremors'),
(87, 'Clammy skin'),
(88, 'Bone deformities'),
(89, 'Delayed growth'),
(90, 'Excessive tiredness'),
(92, 'Slow movement'),
(93, 'Bone pain'),
(94, 'Red spots on the skin'),
(95, 'Brain tumors'),
(96, 'Food cravings'),
(97, 'Changes in sleep patterns'),
(98, 'Anxiety'),
(99, 'Abdominal cramps'),
(100, 'Sadness'),
(101, 'Emotional outbursts'),
(102, 'Bloody stools'),
(103, 'Difficulty in eating'),
(104, 'Flu'),
(105, 'Swollen glands'),
(106, 'Upset stomach');

-- --------------------------------------------------------

--
-- Table structure for table `user_history`
--

CREATE TABLE IF NOT EXISTS `user_history` (
  `uh_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_id` int(10) NOT NULL,
  `his_id` int(10) NOT NULL,
  PRIMARY KEY (`uh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE IF NOT EXISTS `user_master` (
  `um_id` int(10) NOT NULL AUTO_INCREMENT,
  `um_name` varchar(254) NOT NULL,
  `um_cnct` varchar(20) NOT NULL,
  `um_mail` varchar(70) NOT NULL,
  `um_psw` varchar(50) NOT NULL,
  `um_add` text NOT NULL,
  `am_id` int(10) NOT NULL,
  `um_role` varchar(30) NOT NULL,
  `um_bdate` date NOT NULL,
  `um_regdate` datetime NOT NULL,
  `um_img` varchar(254) NOT NULL,
  PRIMARY KEY (`um_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`um_id`, `um_name`, `um_cnct`, `um_mail`, `um_psw`, `um_add`, `am_id`, `um_role`, `um_bdate`, `um_regdate`, `um_img`) VALUES
(10, 'admin', '9874563210', 'admin@admin.com', 'd41d8cd98f00b204e9800998ecf8427e', 'lkasdj flsjdlfk jasdlf jlsadj fljasdlkfjlaskd jflkas djfl jasld fjlkasdf', 0, 'User', '1990-07-19', '0000-00-00 00:00:00', ''),
(11, 'axi', '9876542123', 'asdf@asd.c', '827ccb0eea8a706c4c34a16891f84e7b', 'nana bazar,new vvnagar,anand', 0, 'User', '2019-03-05', '0000-00-00 00:00:00', ''),
(12, 'payal', '9876542130', 'sd@as.c', '71a1428f21cfc63f7881335144cb48e9', 'Av road,vvnagar ,anand', 0, 'User', '2019-03-01', '0000-00-00 00:00:00', ''),
(13, 'nishi', '7986632581', 'nil@gmail.com', 'f87dab8d027236545a2257c668603a4d', 'saktinath, near pachbati,bharuch', 0, 'Doctor', '2019-01-21', '0000-00-00 00:00:00', ''),
(14, 'meghana sharma', '9632548710', 'megh@gamil.com', 'bb69c952b782444e2ded041897ca9396', 'adit campus ,new vvnagar, anand', 0, 'User', '2019-03-21', '0000-00-00 00:00:00', ''),
(15, 'admin', '9632548710', 'ranaaxi27@gmail.com', '2e33a9b0b06aa0a01ede70995674ee23', 'adit campus ,new vvnagar, anand', 0, 'Admin', '2019-03-06', '0000-00-00 00:00:00', ''),
(16, 'Bharat josi ', '9654231078', 'bharat@gmail.com', '44356e89be775e55a3a5a0cf031fa6f5', 'saktinath, near pachbati,bharuch', 0, 'Doctor', '2019-03-08', '0000-00-00 00:00:00', ''),
(17, 'Hema rana', '7986632581', 'hema@gmail.com', 'b59b119b153826a62f5c0be365ed716f', 'Av road,vvnagar ,anand', 0, 'Doctor', '2019-03-22', '0000-00-00 00:00:00', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
