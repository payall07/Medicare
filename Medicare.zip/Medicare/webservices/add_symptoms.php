<?php
	//include "../helth/db.php";
	include 'connection.php';
	$name =$_REQUEST['Symptoms'];

	$MySym = explode(",",$name);
	foreach($MySym as $Name)
	{
		$data=mysqli_query($con, "select * from symptom_master where sm_name='".$Name."'");
		$row=mysqli_fetch_array($data);
		//echo $row['sm_id'];
		$sdis1=mysqli_query($con, "SELECT * FROM `sdis_master` WHERE `sm_id`=".$row['sm_id']);
		while($sdis= mysqli_fetch_array($sdis1))
		{
			$dis[]=$sdis['dis_id'];
		}
	}
	
	/* print_r($dis);
	echo "<br />"; */
	$count=array_count_values($dis);
	arsort($count);
	$keys=array_keys($count);
	//echo $keys[0];
	
	$disis=mysqli_query($con, "select * from disease_master where dis_id='".$keys[0]."'");
	$response["diseases"] = array();
	while ($rows = mysqli_fetch_array($disis)) 
	{
		$response["diseases"][]=$rows;
		$response["success"] = 1;
	}
	echo json_encode($response);
?>