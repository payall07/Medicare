<?php 
	
	include 'connection.php';
	
	$response=array();
	
	$result = mysqli_query($con,"SELECT dis_name , dis_id FROM `disease_master`") or die(mysqli_error($con));
	
	if (mysqli_num_rows($result) > 0) {
	
	 $response["diseases"] = array();
	 
	 while ($row = mysqli_fetch_array($result)) {
        $response["diseases"][]=$row;
	}
	
	$response["success"] = 1;
	
	echo json_encode($response);
} else {

		$response["success"] = 0;
    $response["message"] = "No disease found";

    echo json_encode($response);
	}
?>