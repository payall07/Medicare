<?php 
	include 'connection.php';
	$response=array();
	
	$result = mysqli_query($con,"SELECT * FROM `doctor_master`") or die(mysqli_error($con));
	
	if (mysqli_num_rows($result) > 0) {
	
	 $response["doctors"] = array();
	 
	 while ($row = mysqli_fetch_array($result)) {
		$response["doctors"][]=$row;
	}
	
	$response["success"] = 1;
	
	echo json_encode($response);
} else {

		$response["success"] = 0;
    $response["message"] = "No products found";

    echo json_encode($response);
	}
?>