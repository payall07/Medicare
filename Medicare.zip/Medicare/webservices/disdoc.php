<?php 
	include 'connection.php';
	$dis=$_REQUEST['dis'];
	$response=array();
	
	$result = mysqli_query($con,"SELECT * FROM dis_doc dd, disease_master d, doctor_master s1 where dd.dis_id=d.dis_id and dd.dm_id=s1.dm_id and d.dis_name='".$dis."'") or die(mysqli_error($con));
	
	if (mysqli_num_rows($result) > 0) {
	
	 $response["doctors"] = array();
	 
	 while ($row = mysqli_fetch_array($result)) {
		$response["doctors"][]=$row;
	}
	
	$response["success"] = 1;
	
	echo json_encode($response);
} else {

		$response["success"] = 0;
    $response["message"] = "No products found";

    echo json_encode($response);
	}
?>