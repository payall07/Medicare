<?php
	
	include "connection.php";
	//$um_role = $_POST['spinne']; 
	$um_fname =$_POST['name'];
    $um_bdate = $_POST['birthdate'];
    $um_add = $_POST['address'];
	$um_cnct = $_POST['contact'];
	$um_mail = $_POST['email'];
	$um_psw =$_POST['password'];

	
	$result =  mysqli_query($con, "INSERT INTO `user_master`( `um_name`, `um_cnct`, `um_mail`, `um_psw`, `um_add`, `um_bdate`, `um_regdate`) 
	VALUES ('".$um_fname."', '".$um_cnct."','".$um_mail."','".$um_psw."','".$um_add."','".$um_bdate."',now())");
	$response = array();
	
	if ($result) 
	{
        $response["success"] = 1;
	}
	else
	{
        $response["success"] = 0;
	}
	
	echo json_encode($response);
	
?>