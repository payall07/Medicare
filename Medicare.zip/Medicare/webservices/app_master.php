<?php
	include "connection.php";
	
    $app_date = date("Y-m-d", strtotime($_REQUEST['adate']));
    $time=date("H:i:s", strtotime($_REQUEST['time']));
	$app_desc = $_REQUEST['adesc'];
	$user =$_REQUEST['userid'];
	$doctor =$_REQUEST['doctorid'];
	
	$result =  mysqli_query($con, "INSERT INTO `app_master`(`um_id`, `dm_id`, `app_date`, `app_time`, `app_desc`, `app_regdate`) VALUES ('".$user."', '".$doctor."', '".$app_date."', '".$time."', '".$app_desc."', now())");
	$response = array();
	
	if ($result) 
	{
        $response["success"] = 1;
	}
	else
	{
        $response["success"] = 0;
	}
	
	echo json_encode($response);
	
?>