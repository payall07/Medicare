<?php include 'header.php'; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>Doctors</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">Add New Doctor</h4>
              </div>
			  
			  <form action="doctor_add.php" class="form-horizontal" method="post" role="form">
              <div class="modal-body">
			  <div class="form-group">
				<select class="form-control" name="doctor">
				<option selected disabled>Select Doctor</option>
				<?php
					$chemist=mysqli_query($con, "select * from user_master where um_role ='Doctor'");
					while($a=mysqli_fetch_array($chemist))
					{
				?>
					<option value="<?php echo $a['um_id']; ?>"><?php echo $a['um_name']; ?></option>
				<?php
					}
				?>
			    </select>
			 </div>
               
			    <div class="form-group">
					<input type="text" class="form-control" name="doc" placeholder="Enter Doctor Name">
				 </div>
				 
				 <div class="form-body">
					<input type="text" class="form-control" name="spec" placeholder="Specification ">
				 </div>
				 
				 <div class="form-body">
					<input type="text" class="form-control" name="exp" placeholder="Experiance">
				 </div>
				 
				 <div class="form-body">
					<input type="text" class="form-control" name="study" placeholder="Study "> 
				 </div>
              
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="add" class="btn btn-primary">Save changes</button>
              </div>
			  </form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
					<th>#</th>
					<th>Doctor</th>
					<th>specialist</th>
					<th>Experiance</th>
					<th>Study</th>
					<th>Action</th>
                </tr>
                </thead>
                <tbody>
			<?php
				$i=1;
				$doc=mysqli_query($con, "select * from Doctor_master");
				while($a=mysqli_fetch_array($doc))
				{
			?>
                <tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $a['dm_name']; ?></td>
				<td><?php echo $a['dm_spec']; ?></td>
				<td><?php echo $a['dm_exp']; ?></td>
				<td><?php echo $a['dm_study']; ?></td>
			    <td><a href="doctor_update.php?id=<?php echo $a['dm_id']; ?>" class="btn btn-info">Update</a><a href="doctor_del.php?id=<?php echo $a['dm_id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
			<?php
					$i++;
				}
			?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>