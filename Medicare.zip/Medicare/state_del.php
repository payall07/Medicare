<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		$id=$_REQUEST['id'];
		mysqli_query($con, "DELETE FROM `state_master` WHERE `sm_id`=".$id);
		header("location:state.php");
	}
	else
	{header("location:index.php");}
?>