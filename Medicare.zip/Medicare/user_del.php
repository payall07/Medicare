<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		$id=$_REQUEST['id'];
		mysqli_query($con, "DELETE FROM `user_master` WHERE `um_id`=".$id);
		header("location:user.php");
	}
	else
	{header("location:index.php");}
?>