<?php

	include 'db.php';
	$id=$_REQUEST['id'];
	mysqli_query($con, "DELETE FROM `symptom_master` WHERE sm_id='$id'");
	header("location:symptoms.php");

?>