<?php 

	include 'db.php';
	$id=$_REQUEST['id'];
	if(isset($_POST['submit_btn']))
	{
		$dis=$_POST['dis'];
		$sym=$_POST['sym'];
		
		$query=mysqli_query($con, "UPDATE `sdis_master` SET `dis_id`='".$dis."',`sm_id`='".$sym."' where s_dis_id=".$id);
		
		header("location:sym_dis.php");
	}
?>