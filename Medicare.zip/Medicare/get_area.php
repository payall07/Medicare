<?php
require_once("db.php");
if(!empty($_POST["am_id"])) 
{
$query =mysqli_query($con,"SELECT * FROM area_master WHERE am_id = '" . $_POST["am_id"] . "'");
?>
<option value="">Select area</option>
<?php
while($row=mysqli_fetch_array($query))  
{
?>
<option value="<?php echo $row["am_name"]; ?>"><?php echo $row["am_name"]; ?></option>
<?php
}
}
?>
