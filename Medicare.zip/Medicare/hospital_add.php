<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$hos=$_POST['hosp'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$add=mysqli_real_escape_string($con, $_POST['add']);
			$lat=$_POST['lat'];
			$long=$_POST['long'];
			$desc=mysqli_real_escape_string($con, $_POST['desc']);
			
			
			mysqli_query($con, "INSERT INTO `hospital_master`(`hm_name`, `hm_cnct`, `hm_mail`, `hm_add`, `hm_lat`, `hm_long`, `hm_desc`, `hm_regdate`) VALUES('".$hos."', '".$cnct."', '".$mail."', '".$add."', '".$lat."', '".$long."', '".$desc."', now())") or die(mysqli_error($con));
			
		}
	}
	else
	{header("location:index.php");}
?>