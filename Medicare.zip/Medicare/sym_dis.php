<?php include 'header.php'; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>Symptom-Disease Details</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">New Disease</h4>
              </div>
			  
				<div class="modal-body">
				<div class="form-group">
			    <label>Disease</label>
		<select class="validate[required] form-control" name="dis">
		<option>Select Disease</option>
			<?php
				$disease=mysqli_query($con, "select * from disease_master");
				while($dis=mysqli_fetch_array($disease))
				{
			?>
		<option value="<?php echo $dis['dis_id']; ?>"><?php echo $dis['dis_name']; ?></option>
			<?php
				}
			?>
		</select>
				</div>
					<div class="form-group">
					<label>Sympton</label>
	   <select class="validate[required] form-control" name="sym">
	   <option>Select Sympton</option>
			<?php
				$sympton=mysqli_query($con, "select * from symptom_master");
				while($sym=mysqli_fetch_array($sympton))
				{
			?>
		<option value="<?php echo $sym['sm_id']; ?>"><?php echo $sym['sm_name']; ?></option>
			<?php
				}
			?>
		</select>
				</div>
				</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" name="submit_btn" class="btn btn-primary">Add Disease</button>
				</div>
		</form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Disease</th>
				  <th>Symptom</th>
				  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
			<?php
					$i=1; 
					$query=mysqli_query($con,"SELECT * FROM sdis_master s, disease_master d, symptom_master s1 where                                              s.dis_id=d.dis_id and s.sm_id=s1.sm_id");
					while($rows = mysqli_fetch_array($query))
					{
			?>
				<tr class="odd gradeX">
					<td><?php echo $i;?></td>
					<td><?php echo $rows['dis_name']; ?></td>
					<td><?php echo $rows['sm_name']; ?></td>
					<td><a href="sym_dis_update.php?id=<?php echo $rows['s_dis_id']; ?>" class="btn btn-info">Update</a><a 		                         href="sym_dis_delete.php?id=<?php echo $rows['s_dis_id']; ?>" class="btn btn-danger">Delete</a></td>
				</tr>
				<?php
				$i++;
				}
				?>     </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>