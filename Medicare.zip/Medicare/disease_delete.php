<?php

	include 'db.php';
	$id=$_REQUEST['id'];
	mysqli_query($con, "DELETE FROM `disease_master` WHERE dis_id='$id'");
	header("location:disease.php");

?>