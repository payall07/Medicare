<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{   
			$c1=$_POST['cat'];
			$p1=$_POST['product'];
			$desc=mysqli_real_escape_string($con, $_POST['desc']);
			$price=$_POST['price'];
			$type=$_POST['type'];
			
			
			mysqli_query($con, "INSERT INTO `product_master`(`cat_id`, `pm_name`, `pm_desc`, `pm_price`, `pm_type`) VALUES ('".$c1."', '".$p1."', '".$desc."', '".$price."', '".$type."')") or die(mysqli_error($con));
			header("location:product.php");
		}
	}
	else
	{header("location:index.php");}
?>