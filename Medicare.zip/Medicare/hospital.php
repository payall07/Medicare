<?php include 'header.php'; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>Hospital</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">Add New Hospital</h4>
              </div>
			  <form action="hospital_add.php" class="form-horizontal" method="post" role="form">
              <div class="modal-body">
                <div class="form-group">
                  <input type="text" class="form-control" name="hosp" placeholder="Enter Hospital Name">
				  <input type="text" class="form-control" name="cnct" placeholder="Enter Hospital contact">
				  <input type="text" class="form-control" name="mail" placeholder="Enter Hospital mail">
				  <input type="text" class="form-control" name="add" placeholder="Enter Hospital Address">
				  <input type="text" class="form-control" name="lat" placeholder="Enter Hospital lat">
				  <input type="text" class="form-control" name="long" placeholder="Enter Hospital Long">
				  <input type="text" class="form-control" name="desc" placeholder="Enter Hospital Description">
				  <input type="text" class="form-control" name="regdate" placeholder="Register date">
				  <input type="text" class="form-control" name="logo" placeholder="logo">
				  
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="add" class="btn btn-primary">Save changes</button>
              </div>
			  </form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Hospital</th>
                  <th>contact </th>
				  <th>Mail</th>
				  <th>address</th>
				  <th>Let</th>
				  <th>Long</th>
				  <th>Description</th>
				  <th>regdate</th>
				  <th>logo</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
			<?php
				$i=1;
				$hos=mysqli_query($con, "select * from hospital_master");
				while($h1=mysqli_fetch_array($hos))
				{
			?>
                <tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $h1['hm_name']; ?></td>
					<td><?php echo $h1['hm_cnct']; ?></td>
					<td><?php echo $h1['hm_mail']; ?></td>
					<td><?php echo $h1['hm_add']; ?></td>
					<td><?php echo $h1['hm_lat']; ?></td>
					<td><?php echo $h1['hm_long']; ?></td>
					<td><?php echo $h1['hm_desc']; ?></td>
					<td><?php echo date("M d, Y", strtotime($h1['hm_regdate'])); ?></td>
					<td><?php echo $c1['cm_logo']; ?></td>
					<td><a href="hospital_update.php?id=<?php echo $h1['hm_id']; ?>" class="btn btn-info">Update</a><a href="hospital_del.php?id=<?php echo $h1['hm_id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
			<?php
					$i++;
				}
			?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>