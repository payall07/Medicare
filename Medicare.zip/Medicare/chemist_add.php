<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$c1=$_POST['chemist'];
			$cnct=$_POST['cnct'];
			$mail=$_POST['mail'];
			$addr=$_POST['addr'];
			$am=$_POST['state'];
			$am=$_POST['city'];
			$lat=$_POST['lat'];
			$long=$_POST['long'];
			$desc=$_POST['desc'];
			$logo=$_FILES['logo']['name'];
			$tmp=$_FILES['logo']['tmp_name'];
			move_uploaded_file($tmp, "images/chemist/".$logo);
			
			mysqli_query($con, "INSERT INTO `chemist_master`(`cm_name`, `cm_cnct`, `cm_mail`, `cm_add`, `am_id`, `cm_lat`, `cm_long`, `cm_desc`, `cm_regdate`, `cm_logo`) VALUES('".$c1."', '".$cnct."', '".$mail."', '".$addr."', '".$am."', '".$lat."', '".$long."', '".$desc."', now(), 'images/chemist/".$logo."')")or die(mysqli_error($con));
			header("location:chemist.php");
		}
	}
	else
	{header("location:index.php");}
?>