<?php
	session_start();
	include 'db.php';
	if(isset($_SESSION['userid']))
	{
		if(isset($_POST['add']))
		{
			$city=$_POST['city'];
			$a1=$_POST['area'];
			$pin=$_POST['pin'];
			mysqli_query($con, "INSERT INTO `area_master`(`ct_id`, `am_name`, `am_pin`) VALUES ('".$city."', '".$a1."', '".$pin."')");
			header("location:area.php");
		}
	}
	else
	{header("location:index.php");}
?>


