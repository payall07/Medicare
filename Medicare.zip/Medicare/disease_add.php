<?php 
	
	include 'db.php';
	if(isset($_POST['submit_btn']))
	{
		$name=$_POST['dis_name'];
		
		$query=mysqli_query($con, "INSERT INTO `disease_master`(`dis_name`) VALUES ('".$name."')") or mysqli_error();
		header("location:disease.php");
	}
?>