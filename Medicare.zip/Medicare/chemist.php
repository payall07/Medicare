<?php include 'header.php'; ?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script>
	function getcity(val) {
		$.ajax({
		type: "POST",
		url: "get_city.php",
		data:'sm_id='+val,
		success: function(data){
			$("#city-list").html(data);}
		});
	}
	function getarea(val) {
		$.ajax({
		type: "POST",
		url: "get_city.php",
		data:'ct_id='+val,
		success: function(data){
			$("#area-list").html(data);}
		});
	}
</script>
</head>
</html>


  <div class="content-wrapper">
    <section class="content-header">
      <div class="col-xs-6"><h3>Categories</h3></div>
	  <div class="col-xs-6" align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-default">Add New</button></div>
	  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
				</button>
                <h4 class="modal-title">Add New Chemist</h4>
              </div>
			  <form action="chemist_add.php" method="post" enctype="multipart/form-data">
			  <div class="modal-body">
			  	<div class="form-group">
			      <input type="text" class="form-control" name="chemist" placeholder="Enter Chemist Name">
				</div>
			  	<div class="form-group">  
				  <input type="text" class="form-control" name="cnct" placeholder="Enter Chemist contact">
		    	</div>		  
			  	<div class="form-group"> 
			   	  <input type="text" class="form-control" name="mail" placeholder="Enter Chemist mail">
				</div>   
			    <div class="form-group">
				   <input type="text" class="form-control" name="cnctper" placeholder="Enter Chemist cncpter">
			    </div>	   
			    <div class="form-group">	   
				  <input type="text" class="form-control" name="addr" placeholder="Enter Chemist Address">
			    </div>
				<div class="form-group">
					<select name="state" class="form-control" onChange="getcity(this.value);">
						<option value="">Select state</option>
						<?php $query =mysqli_query($con,"SELECT * FROM state_master");
						while($row=mysqli_fetch_array($query)) { ?>
						<option value="<?php echo $row['sm_id']; ?>"><?php echo $row['sm_name'];?> </option>
						<?php } ?>
					</select>
				</div>						
				<div class="form-group">
					<select name="city" id="city-list" class="form-control" onChange="getarea(this.value);">
						<option value="">Select city</option>
					</select>
				</div>
                <div class="form-group">
					<select name="city" id="area-list" class="form-control">
						<option value="">Select area</option>
					</select>
				</div>
				<div class="form-group">
				  <input type="text" class="form-control" name="lat" placeholder="Enter Chemist lat">
			    </div>
				<div class="form-group">
				  <input type="text" class="form-control" name="long" placeholder="Enter Chemist Long">
				</div>
			    <div class="form-group">
				  <input type="text" class="form-control" name="desc" placeholder="Enter Chemist Description">
				</div>
			    <div class="form-group">
				  <input type="file" name="logo" style="opacity: 1; height: 20px;">
				</div><br />
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" name="add" class="btn btn-primary">Save changes</button>
              </div>
			  </form>
            </div>
          </div>
        </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Chemist</th>
				  <th>contact </th>
				  <th>Mail</th>
				  <th>cncpter</th>
				  <th>address</th>
				  <th>State</th>
				  <th>City</th>
				  <th>Let</th>
				  <th>Long</th>
				  <th>Description</th>
				  <th>regdate</th>
				  <th>logo</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
			<?php
				$i=1;
				$chemist=mysqli_query($con, "select * from chemist_master");
				while($c1=mysqli_fetch_array($chemist))
				{
			?>
                <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $c1['cm_name']; ?></td>
				   <td><?php echo $c1['cm_cnct']; ?></td>
				    <td><?php echo $c1['cm_mail']; ?></td>
					<td><?php echo $c1['cm_cnctper']; ?></td>
					 <td><?php echo $c1['cm_add']; ?></td>
					 <td><?php echo $c1['sm_name']; ?></td>
					  <td><?php echo $c1['ct_name']; ?></td>
					 <td><?php echo $c1['am_name']; ?></td>
					  <td><?php echo $c1['cm_lat']; ?></td>
					   <td><?php echo $c1['cm_logo']; ?></td>
				  <td><?php echo $c1['cm_desc']; ?></td>
				   <td><?php echo $c1['cm_regdate']; ?></td>
				   <td><?php echo $c1['cm_logo']; ?></td>
                  <td><a href="chemist_update.php?id=<?php echo $c1['cm_id']; ?>" class="btn btn-info">Update</a><a href="chemist_del.php?id=<?php echo $c1['cm_id']; ?>" class="btn btn-danger">Delete</a></td>
                </tr>
			<?php
					$i++;
				}
			?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include 'footer.php'; ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>