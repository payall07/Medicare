<?php 
	
	include 'db.php';
	$id=$_REQUEST['id'];
	mysqli_query($con, "DELETE FROM `sdis_master` WHERE s_dis_id='$id'");
	header("location:sym_dis.php");


?>